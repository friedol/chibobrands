/**
  * Optimized Admin Framework JS
  * Consolidated for maximum performance
  */
(function () {
    const preloader = document.getElementById("preloader");

    // 1. Instant Page Reveal (Optimized)
    const revealPage = () => {
        if (preloader && !preloader.classList.contains('fade-out')) {
            preloader.classList.add("fade-out");
            setTimeout(() => preloader.classList.remove("show"), 200);
        }
    };

    if (document.readyState === "complete" || document.readyState === "interactive") {
        revealPage();
    } else {
        window.addEventListener("DOMContentLoaded", revealPage);
    }
    setTimeout(revealPage, 1000); // Fallback

    document.addEventListener("DOMContentLoaded", function () {
        // 2. Optimized Navigation & Preloader Logic
        const handlePreloader = (e) => {
            const link = e.target.closest('a');
            if (!link || link.hasAttribute('data-no-preloader') || link.target === '_blank' || link.href.includes('#')) return;

            // Only show if it's a real navigation to a different URL
            if (link.href && link.href !== window.location.href && !link.href.startsWith('javascript:')) {
                if (preloader) {
                    preloader.classList.add("show");
                    preloader.classList.remove("fade-out");
                }
            }
        };

        // Global event delegation for links
        document.body.addEventListener('click', handlePreloader);

        // Form Submissions
        // Form Submissions
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function (e) {
                // Check if form has bypass attribute
                if (this.hasAttribute('data-no-preloader') || this.id === 'logout-form') return;

                // Check if the specific button clicked has bypass attribute
                if (e.submitter && (e.submitter.hasAttribute('data-no-preloader') || e.submitter.hasAttribute('data-no-global-handler'))) return;

                if (preloader && this.checkValidity()) {
                    preloader.classList.add("show");
                    preloader.classList.remove("fade-out");
                }
            });
        });

        // 3. Instant Logout Handler
        const logoutForm = document.getElementById('logout-form');
        if (logoutForm) {
            logoutForm.addEventListener('submit', () => {
                const btn = logoutForm.querySelector('.logout-btn');
                if (btn) btn.disabled = true;
            });
        }

        // 4. Sidebar & Menu Logic (Consolidated)
        // Note: Sidebar logic is handled in the dedicated section below to support full features
        // like closing on link click, resize handling, etc.

        // Submenu Logic
        // Submenu Logic - Deprecated here, handled by "Sidebar State Management" block below
        // to support persistence and advanced features.

        // 5. Scroll Performance
        let ticking = false;
        const navbar = document.querySelector('.top-navbar');
        window.addEventListener('scroll', () => {
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    const top = window.pageYOffset || document.documentElement.scrollTop;
                    navbar.classList.toggle('scrolled', top > 50);
                    // navbar.style.transform = `translateY(${top > 200 ? '-100%' : '0'})`;
                    ticking = false;
                });
                ticking = true;
            }
        });
    });
})();
// Share Links Modal helper
document.addEventListener('DOMContentLoaded', function () {
    const modalEl = document.getElementById('shareLinksModal');
    if (!modalEl) return;
    const phoneWarning = modalEl.querySelector('#salerPhoneWarning');
    const copyButtons = modalEl.querySelectorAll('[data-copy-target]');
    copyButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            const target = document.querySelector(this.getAttribute('data-copy-target'));
            if (target) {
                target.select();
                document.execCommand('copy');
                showSuccessToast('Link copied to clipboard');
            }
        });
    });
});

// Handle submenu toggle
// Handle submenu toggle & Sidebar State Management
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.querySelector('.sidebar');
    const submenuItems = document.querySelectorAll('[data-submenu-toggle]');
    const storageKey = 'admin_sidebar_state';

    // 1. Restore State
    const savedState = JSON.parse(localStorage.getItem(storageKey) || '{"openMenus":[], "scrollTop":0}');

    // Restore Scroll Position
    if (sidebar && savedState.scrollTop) {
        sidebar.scrollTop = savedState.scrollTop;
    }

    submenuItems.forEach(function (item, index) {
        const link = item.querySelector('.nav-link');
        const submenu = item.querySelector('.nav-submenu');
        // Use a unique identifier for the menu item (href of link or index)
        const menuId = link.getAttribute('href') || 'menu-' + index;
        item.dataset.menuId = menuId; // Store ID on element for saving later

        if (!submenu) return;

        // Check if submenu has active link on page load (Server Side Priority)
        const hasActiveSubmenu = submenu.querySelector('.nav-link.active');

        // Restore Open State (Client Side) OR Server Side Active
        if (savedState.openMenus.includes(menuId) || hasActiveSubmenu) {
            item.classList.add('active');
        }

        // Handle clicks on the main link
        link.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            item.classList.toggle('active');
            saveSidebarState();
        });
    });

    // 2. Save State Function
    function saveSidebarState() {
        const openMenus = [];
        document.querySelectorAll('[data-submenu-toggle].active').forEach(item => {
            if (item.dataset.menuId) openMenus.push(item.dataset.menuId);
        });

        const state = {
            openMenus: openMenus,
            scrollTop: sidebar ? sidebar.scrollTop : 0
        };

        localStorage.setItem(storageKey, JSON.stringify(state));
    }

    // 3. Save Scroll Position on Scroll
    if (sidebar) {
        let scrollTimeout;
        sidebar.addEventListener('scroll', () => {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(saveSidebarState, 100);
        });
    }
});

// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.querySelector('.sidebar');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    // Toggle sidebar
    function toggleSidebar() {
        sidebar.classList.toggle('active');
        sidebarOverlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
    }

    // Open sidebar
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', toggleSidebar);
    }

    // Close sidebar when clicking overlay
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', toggleSidebar);
    }

    // Close sidebar when clicking a nav link on mobile (exclude logout button)
    const navLinks = document.querySelectorAll('.sidebar .nav-link:not(.logout-btn)');
    navLinks.forEach(link => {
        link.addEventListener('click', function () {
            // Don't close sidebar if clicking a submenu toggle
            if (link.nextElementSibling && link.nextElementSibling.classList.contains('nav-submenu')) {
                return;
            }

            if (window.innerWidth <= 992) {
                toggleSidebar();
            }
        });
    });

    // Close sidebar on window resize if screen becomes large
    window.addEventListener('resize', function () {
        if (window.innerWidth > 992) {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Handle escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && sidebar.classList.contains('active')) {
            toggleSidebar();
        }
    });
});

// Auto-hide alerts
setTimeout(function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        if (alert.parentNode) {
            alert.remove();
        }
    });
}, 5000);

// Add loading states to buttons (excluding logout)
// Add loading states to buttons (excluding logout and bypassed buttons)
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('button[type="submit"]').forEach(button => {
        // Skip if button has custom handler or is logout button (Initial Check)
        if (button.hasAttribute('data-no-global-handler') ||
            button.hasAttribute('data-no-preloader') ||
            button.classList.contains('logout-btn') ||
            button.closest('form')?.action.includes('logout')) {
            return;
        }

        const originalText = button.innerHTML;

        button.addEventListener('click', function (e) {
            // Safety Check: re-verify attributes at runtime
            if (this.hasAttribute('data-no-global-handler') || this.hasAttribute('data-no-preloader')) {
                return;
            }

            if (this.form && this.form.checkValidity()) {
                this.innerHTML = '<span class="loading"></span> Processing...';
                this.disabled = true;

                // Reset button after form submission (success or error)
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 5000); // Reset after 5 seconds
            }
        });
    });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add hover effects to cards
document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', function () {
        this.style.transform = 'translateY(-5px)';
    });

    card.addEventListener('mouseleave', function () {
        this.style.transform = 'translateY(0)';
    });
});

// Smart navbar - hide/show on scroll
let lastScrollTop = 0;
const navbar = document.querySelector('.top-navbar');

window.addEventListener('scroll', function () {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }

    // Hide navbar when scrolling down, show when scrolling up
    /*
    if (scrollTop > lastScrollTop && scrollTop > 200) {
        navbar.style.transform = 'translateY(-100%)';
    } else {
        navbar.style.transform = 'translateY(0)';
    }
    */

    lastScrollTop = scrollTop;
});
function showNotification(message, type = 'success', title = null, duration = 5000) {
    const container = document.getElementById('notificationContainer');

    // Set default titles
    const titles = {
        success: title || 'Success!',
        error: title || 'Error!',
        warning: title || 'Warning!',
        info: title || 'Information'
    };

    // Set icons
    const icons = {
        success: '<i class="fas fa-check-circle"></i>',
        error: '<i class="fas fa-times-circle"></i>',
        warning: '<i class="fas fa-exclamation-triangle"></i>',
        info: '<i class="fas fa-info-circle"></i>'
    };

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `custom-notification ${type}`;
    notification.innerHTML = `
                <div class="notification-icon ${type}">
                    ${icons[type]}
                </div>
                <div class="notification-content">
                    <div class="notification-title">${titles[type]}</div>
                    <div class="notification-message">${message}</div>
                </div>
                <button class="notification-close" onclick="closeNotification(this)">
                    <i class="fas fa-times"></i>
                </button>
                <div class="notification-progress"></div>
            `;

    container.appendChild(notification);

    // Auto remove after duration
    setTimeout(() => {
        closeNotification(notification.querySelector('.notification-close'));
    }, duration);
}

function closeNotification(button) {
    const notification = button.closest('.custom-notification');
    notification.classList.add('hiding');
    setTimeout(() => {
        notification.remove();
    }, 400);
}

// Session messages are handled in the Blade template
// Use window.showSessionNotifications() to display them

// Modern Confirmation Modal System
window.modernConfirm = function (message, onConfirm, options = {}) {
    const defaults = {
        title: 'Confirm Action',
        confirmText: 'Confirm',
        cancelText: 'Cancel',
        type: 'warning', // warning, danger, success, info
        icon: 'fa-exclamation-triangle'
    };

    const settings = { ...defaults, ...options };

    // Create modal HTML
    const modalHTML = `
                <div class="modern-confirm-overlay" id="modernConfirmModal">
                    <div class="modern-confirm-modal">
                        <div class="modern-confirm-icon ${settings.type}">
                            <i class="fas ${settings.icon}"></i>
                        </div>
                        <h3 class="modern-confirm-title">${settings.title}</h3>
                        <p class="modern-confirm-message">${message}</p>
                        <div class="modern-confirm-actions">
                            <button class="modern-confirm-btn cancel" onclick="closeModernConfirm()">
                                <i class="fas fa-times me-2"></i>${settings.cancelText}
                            </button>
                            <button class="modern-confirm-btn confirm ${settings.type}" id="modernConfirmBtn">
                                <i class="fas fa-check me-2"></i>${settings.confirmText}
                            </button>
                        </div>
                    </div>
                </div>
            `;

    // Add to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    // Add event listeners
    document.getElementById('modernConfirmBtn').addEventListener('click', function () {
        closeModernConfirm();
        onConfirm();
    });

    // Close on overlay click
    document.getElementById('modernConfirmModal').addEventListener('click', function (e) {
        if (e.target === this) {
            closeModernConfirm();
        }
    });

    // Close on Escape key
    document.addEventListener('keydown', function escapeHandler(e) {
        if (e.key === 'Escape') {
            closeModernConfirm();
            document.removeEventListener('keydown', escapeHandler);
        }
    });

    // Animate in
    setTimeout(() => {
        document.getElementById('modernConfirmModal').classList.add('show');
    }, 10);

    return false; // Prevent default form submission
};

window.closeModernConfirm = function () {
    const modal = document.getElementById('modernConfirmModal');
    if (modal) {
        modal.classList.remove('show');
        setTimeout(() => {
            modal.remove();
        }, 300);
    }
};

// Toast notification function for admin
function showSuccessToast(message) {
    // Check if toast container exists, if not create it
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'position-fixed top-0 end-0 p-3';
        toastContainer.style.zIndex = '9999';
        document.body.appendChild(toastContainer);
    }

    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toastHtml = `
                <div id="${toastId}" class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="d-flex">
                        <div class="toast-body">
                            <i class="fas fa-check-circle me-2"></i>${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                </div>
            `;

    toastContainer.insertAdjacentHTML('beforeend', toastHtml);

    // Initialize and show toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 3000
    });

    toast.show();

    // Remove toast element after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function () {
        toastElement.remove();
    });
}

// Smart Notification Features
(function () {
    // Mark notification as read
    window.markNotificationRead = function (notificationId) {
        fetch(`/admin/notifications/${notificationId}/read`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json'
            }
        })
            .then(response => response.json())
            .then(data => {
                // Remove notification from list
                const notificationItem = document.querySelector(`[data-notification-id="${notificationId}"]`);
                if (notificationItem) {
                    notificationItem.closest('li').style.opacity = '0.5';
                    setTimeout(() => {
                        notificationItem.closest('li').remove();
                        updateNotificationCount();
                    }, 300);
                }
            })
            .catch(error => {
                console.error('Error marking notification as read:', error);
                // Fallback: redirect to notification page
                window.location.href = `/admin/notifications/${notificationId}`;
            });
    };

    // Mark all notifications as read
    const markAllReadBtn = document.querySelector('.mark-all-read-btn');
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            fetch(window.adminConfig?.routes?.notificationsMarkAllRead || '/admin/notifications/mark-all-read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Accept': 'application/json'
                }
            })
                .then(response => {
                    if (response.ok) {
                        // Clear all notifications from dropdown
                        if (notificationList) {
                            notificationList.innerHTML = `
                                <div class="p-5 text-center">
                                    <div class="mb-3">
                                        <i class="fas fa-check-circle text-success" style="font-size: 2.5rem; opacity: 0.5;"></i>
                                    </div>
                                    <p class="text-muted small mb-0">You're all caught up!</p>
                                </div>
                            `;
                        }
                        updateNotificationCount();
                        // Close dropdown
                        const dropdown = bootstrap.Dropdown.getInstance(document.getElementById('notificationDropdown'));
                        if (dropdown) {
                            dropdown.hide();
                        }
                    } else {
                        // Fallback: reload page
                        window.location.reload();
                    }
                })
                .catch(error => {
                    console.error('Error marking all as read:', error);
                    window.location.href = window.adminConfig?.routes?.notificationsIndex || '/admin/notifications';
                });
        });
    }

    // Update notification count badge
    function updateNotificationCount() {
        const notificationList = document.getElementById('notificationList');
        const remainingNotifications = notificationList.querySelectorAll('.notification-item').length;
        const badge = document.querySelector('#notificationDropdown .badge');
        const headerBadge = document.querySelector('.notification-dropdown .dropdown-header .badge');

        if (remainingNotifications === 0) {
            if (badge) badge.remove();
        } else {
            if (badge) badge.textContent = remainingNotifications > 99 ? '99+' : remainingNotifications;
        }
    }

    // Optimized Auto-refresh with Visibility Check & Sound Alerts
    let notificationRefreshInterval;
    let lastKnownNotificationId = null;
    let isInitialLoad = true;

    function startNotificationRefresh() {
        if (!window.location.pathname.startsWith('/admin')) return;

        const refresh = () => {
            const dropdown = bootstrap.Dropdown.getInstance(document.getElementById('notificationDropdown'));
            // Still refresh if dropdown is closed to update badge and play sound
            if (document.visibilityState === 'visible' && (!dropdown || !dropdown._isShown())) {
                refreshNotifications();
            }
        };

        notificationRefreshInterval = setInterval(refresh, 30000); // 30 seconds for better responsiveness
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') refresh();
        });

        // Initial check
        setTimeout(refresh, 1000);
    }

    // Refresh notifications count and list
    function refreshNotifications() {
        fetch(window.adminConfig?.routes?.notificationsRefreshCount || '/admin/notifications/refresh-count', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
            .then(response => response.json())
            .then(data => {
                const badge = document.querySelector('#notificationDropdown .badge');
                const sidebarBadge = document.querySelector('.sidebar .nav-link[href*="notifications"] .badge');

                // Update badge in top bar
                if (data.count > 0) {
                    if (badge) {
                        badge.textContent = data.count > 99 ? '99+' : data.count;
                    } else {
                        const icon = document.querySelector('#notificationDropdown i');
                        if (icon) {
                            const newBadge = document.createElement('span');
                            newBadge.className = 'position-absolute translate-middle badge rounded-pill bg-danger';
                            newBadge.style = 'top: 8px; right: -5px; border: 2px solid #fff; font-size: 0.65rem; min-width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; padding: 0;';
                            newBadge.textContent = data.count > 99 ? '99+' : data.count;
                            icon.parentElement.appendChild(newBadge);
                        }
                    }

                    // Update sidebar badge if it exists
                    if (sidebarBadge) {
                        sidebarBadge.textContent = data.count;
                        sidebarBadge.style.display = 'inline-block';
                    }
                } else {
                    if (badge) badge.remove();
                    if (sidebarBadge) sidebarBadge.style.display = 'none';
                }


                // Check for new notification
                if (data.latest && data.latest.id !== lastKnownNotificationId) {
                    // Play sound for new notifications (including on initial load if unread exists)
                    playNotificationSound(data.latest.id);

                    // Only show toast if not initial load (to avoid spam on login)
                    if (!isInitialLoad) {
                        showNotification(
                            `<strong>${data.latest.title}</strong><br>${data.latest.message}<br><a href="${data.latest.url}" class="btn btn-sm btn-light mt-2 p-1 px-2" style="font-size: 0.7rem;">View Details</a>`,
                            'info',
                            'New Activity',
                            10000
                        );
                    }
                    lastKnownNotificationId = data.latest.id;
                }
                isInitialLoad = false;
            })
            .catch(error => console.error('Error refreshing notifications:', error));
    }

    function playNotificationSound(notificationId) {
        // Check if we already played sound for this notification today
        const lastPlayed = JSON.parse(localStorage.getItem('notification_sound_log') || '{}');
        const today = new Date().toDateString();

        if (lastPlayed.id === notificationId && lastPlayed.date === today) {
            return; // Already played for this notification today
        }

        const sound = document.getElementById('notificationSound');
        if (sound) {
            sound.currentTime = 0;
            sound.play()
                .then(() => {
                    // Log that we played sound for this notification
                    localStorage.setItem('notification_sound_log', JSON.stringify({
                        id: notificationId,
                        date: today
                    }));
                })
                .catch(e => console.log('Audio playback blocked:', e));
        }
    }

    // Refresh full list when opening dropdown
    document.getElementById('notificationDropdown')?.addEventListener('show.bs.dropdown', function () {
        const list = document.getElementById('notificationList');
        if (list) {
            list.style.opacity = '0.7';
            // We could fetch the full list here if there's a route for it
            // For now, we at least ensure the badge is accurate
            refreshNotifications();
            setTimeout(() => list.style.opacity = '1', 200);
        }
    });

    // Start auto-refresh on page load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startNotificationRefresh);
    } else {
        startNotificationRefresh();
    }

    // Clean up interval on page unload
    window.addEventListener('beforeunload', function () {
        if (notificationRefreshInterval) {
            clearInterval(notificationRefreshInterval);
        }
    });

    // Handle responsive dropdown positioning
    function adjustDropdownPosition() {
        if (window.innerWidth <= 768) {
            const dropdowns = document.querySelectorAll('.notification-dropdown, .message-dropdown');
            dropdowns.forEach(dropdown => {
                dropdown.style.position = 'fixed';
                dropdown.style.right = '1rem';
                dropdown.style.left = 'auto';
            });
        }
    }

    window.addEventListener('resize', adjustDropdownPosition);

    // Enable audio playback on first user interaction (required by browsers)
    // Enable audio playback on first user interaction (required by browsers)
    function unlockAudio() {
        const sound = document.getElementById('notificationSound');
        if (sound) {
            // Mute, play, then pause and unmute to unlock without sound
            sound.muted = true;
            sound.play().then(() => {
                sound.pause();
                sound.currentTime = 0;
                sound.muted = false; // Unmute for future real notifications
            }).catch(() => { });
        }
        document.removeEventListener('click', unlockAudio);
        document.removeEventListener('keydown', unlockAudio);
    }
    document.addEventListener('click', unlockAudio, { once: true });
    document.addEventListener('keydown', unlockAudio, { once: true });
    adjustDropdownPosition();
})();